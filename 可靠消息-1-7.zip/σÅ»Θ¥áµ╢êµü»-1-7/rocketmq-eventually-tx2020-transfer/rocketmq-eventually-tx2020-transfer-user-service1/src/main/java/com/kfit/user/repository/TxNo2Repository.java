package com.kfit.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kfit.user.bean.TxNo2;

public interface TxNo2Repository extends JpaRepository<TxNo2, String> {

}
